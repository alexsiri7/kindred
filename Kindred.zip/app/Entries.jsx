/* Entries list page */

const ReadOnlyBanner = () => (
  <div className="readonly-banner">
    <span className="lock">🔒</span>
    <span><strong>Read-only.</strong> Entries are written through the journaling conversation in Claude — not from here.</span>
  </div>
);

const EntriesList = ({ onOpen }) => {
  // group by month
  const byMonth = {};
  ENTRIES.forEach(e => {
    const key = `${e.month} 2026`;
    if (!byMonth[key]) byMonth[key] = [];
    byMonth[key].push(e);
  });

  return (
    <>
      <div className="page-head">
        <div className="page-eye"><span className="glyph">✶</span> Your library</div>
        <h1 className="page-title">A record of <em>being with</em> yourself.</h1>
        <p className="page-sub">{ENTRIES.length} entries since you started in March. Sorted by most recent. Click any entry to read the full thing.</p>
      </div>
      <ReadOnlyBanner/>
      {Object.entries(byMonth).map(([month, items]) => (
        <div key={month}>
          <div className="month-div">{month}</div>
          {items.map(e => (
            <div key={e.id} className="entry-row" onClick={() => onOpen(e.id)}>
              <div className="entry-date">
                <span className="day">{e.day}</span>
                {e.weekday}
              </div>
              <div className="entry-body">
                <h3>{e.title}</h3>
                <p>{e.summary.length > 200 ? e.summary.slice(0, 200) + '…' : e.summary}</p>
                {e.occurrences.length > 0 && (
                  <div className="entry-tags">
                    {e.occurrences.map((o, i) => (
                      <span key={i} className="tag-pill">{o.pattern}</span>
                    ))}
                  </div>
                )}
              </div>
              <div className="entry-meta">
                <span className="mood">◉ {e.mood}</span>
                {e.wordCount} words
              </div>
            </div>
          ))}
        </div>
      ))}
    </>
  );
};

window.EntriesList = EntriesList;
window.ReadOnlyBanner = ReadOnlyBanner;
