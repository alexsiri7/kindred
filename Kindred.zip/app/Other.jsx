/* Search + Settings + Connect */

const Search = ({ onOpen }) => {
  const [q, setQ] = React.useState('the static feeling');

  // simulate semantic results — score by naive word overlap, but keep "tender" feel
  const results = q.trim() ? [
    { entry: ENTRIES[0], score: 0.91, snippet: 'a kind of <mark>low static</mark>. I keep refreshing my email like that\'ll fix it. Bracing for something I can\'t name.' },
    { entry: ENTRIES[3], score: 0.74, snippet: 'hit the 3pm wall hard. Foggy. <mark>A little defeated</mark>. I keep trying to push through.' },
    { entry: ENTRIES[5], score: 0.68, snippet: 'spent an hour writing increasingly elaborate apology messages I didn\'t send. <mark>Sharp guilt</mark>.' },
    { entry: ENTRIES[7], score: 0.61, snippet: 'the night-before-flying feeling. <mark>Buzzy</mark>. Hard to sit still. Mind making lists about things already on lists.' },
  ] : [];

  return (
    <>
      <div className="page-head">
        <div className="page-eye"><span className="glyph">✶</span> Search</div>
        <h1 className="page-title">Find by <em>feeling</em>, not just date.</h1>
        <p className="page-sub">Semantic search over your entry summaries. Try phrases — "the bracing feeling", "afternoon slump", "something about my dad". Powered by pgvector + small embeddings.</p>
      </div>

      <div className="search-bar">
        <Icon name="search" size={20}/>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="What are you looking for?" autoFocus/>
        <span className="hint">{results.length} matches</span>
      </div>

      {results.map((r, i) => (
        <div key={i} className="search-result" onClick={() => onOpen(r.entry.id)}>
          <div className="search-result-head">
            <span className="search-result-date">
              {new Date(r.entry.date + 'T12:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
              <span style={{margin:'0 8px', color:'var(--ink-4)'}}>·</span>
              <em style={{fontFamily:'var(--font-display)', fontStyle:'italic', fontSize:14, color:'var(--ink)'}}>{r.entry.title}</em>
            </span>
            <span className="search-result-score">{(r.score * 100).toFixed(0)}% match</span>
          </div>
          <p className="search-result-snippet" dangerouslySetInnerHTML={{__html: r.snippet}}/>
        </div>
      ))}
    </>
  );
};

const Settings = () => {
  const [transcripts, setTranscripts] = React.useState(true);
  const [tz, setTz] = React.useState('Europe/London');

  return (
    <>
      <div className="page-head">
        <div className="page-eye"><span className="glyph">✶</span> Settings</div>
        <h1 className="page-title">Your <em>data</em>, your terms.</h1>
        <p className="page-sub">A few small toggles. Nothing else hidden behind submenus.</p>
      </div>

      <div className="set-section">
        <div>
          <div className="set-label">Timezone</div>
          <p className="set-help">Used for the "user-local date" of each entry.</p>
        </div>
        <div className="set-control">
          <select value={tz} onChange={(e) => setTz(e.target.value)}>
            <option>Europe/London</option><option>America/New_York</option><option>America/Los_Angeles</option>
            <option>Europe/Berlin</option><option>Asia/Tokyo</option><option>Australia/Sydney</option>
          </select>
        </div>
      </div>

      <div className="set-section">
        <div>
          <div className="set-label">Save transcripts</div>
          <p className="set-help">Stores the full conversation alongside the summary. You can flip to summary-only if it feels too much.</p>
        </div>
        <div className="set-control">
          <label className={`toggle ${transcripts ? 'on' : ''}`} onClick={() => setTranscripts(t => !t)}>
            <span className="toggle-track"><span className="toggle-thumb"/></span>
            <span className="toggle-label">{transcripts ? 'On — summary + transcript' : 'Off — summary only'}</span>
          </label>
        </div>
      </div>

      <div className="set-section">
        <div>
          <div className="set-label">Export everything</div>
          <p className="set-help">A JSON dump of every entry, pattern, and occurrence. Yours to take.</p>
        </div>
        <div className="set-control">
          <button className="btn btn-secondary"><Icon name="download" size={14}/> Export as JSON</button>
        </div>
      </div>

      <div className="set-section">
        <div>
          <div className="set-label">Delete account</div>
          <p className="set-help">Hard delete, cascading across all tables. No "are you sure" theatre — just one confirm.</p>
        </div>
        <div className="set-control">
          <button className="btn btn-danger"><Icon name="trash" size={14}/> Delete everything</button>
        </div>
      </div>
    </>
  );
};

const Connect = () => (
  <>
    <div className="page-head">
      <div className="page-eye"><span className="glyph">✶</span> Connector</div>
      <h1 className="page-title">Add Kindred to <em>Claude</em>.</h1>
      <p className="page-sub">Two minutes. Paste this into Claude.ai's connector settings. Once connected, the three slash commands light up.</p>
    </div>

    <div style={{
      background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:'var(--r-lg)',
      padding:'var(--sp-5)', marginBottom:'var(--sp-5)'
    }}>
      <div className="entry-section-eye">Step 1 · MCP server URL</div>
      <div style={{display:'flex', gap:8, alignItems:'center', marginBottom:'var(--sp-4)'}}>
        <code style={{flex:1, padding:'12px 14px', background:'var(--paper-2)', border:'1px solid var(--border)', borderRadius:'var(--r-md)', fontFamily:'var(--font-mono)', fontSize:13, color:'var(--ink)'}}>
          https://mcp.kindred.app/sse
        </code>
        <button className="btn btn-secondary">Copy</button>
      </div>

      <div className="entry-section-eye">Step 2 · Connector token</div>
      <div style={{display:'flex', gap:8, alignItems:'center', marginBottom:'var(--sp-4)'}}>
        <code style={{flex:1, padding:'12px 14px', background:'var(--paper-2)', border:'1px solid var(--border)', borderRadius:'var(--r-md)', fontFamily:'var(--font-mono)', fontSize:13, color:'var(--ink-3)'}}>
          kdr_••••••••••••••••••••••••3a2f
        </code>
        <button className="btn btn-secondary">Reveal</button>
        <button className="btn btn-secondary">Rotate</button>
      </div>

      <div className="entry-section-eye">Step 3 · Try it</div>
      <p style={{color:'var(--ink-2)', fontSize:14, lineHeight:1.55, margin:'8px 0 0', maxWidth:'56ch'}}>
        In Claude.ai, type <code style={{background:'var(--paper-2)', padding:'2px 6px', borderRadius:4, fontFamily:'var(--font-mono)', fontSize:13}}>/kindred-start</code> to begin a session.
        That's it. The connector token will migrate to OAuth automatically once it's shipped.
      </p>
    </div>
  </>
);

window.Search = Search;
window.Settings = Settings;
window.Connect = Connect;
