/* Patterns list + detail */

const Sparkline = ({ data, highlight = -1 }) => (
  <div className="sparkline" aria-hidden="true">
    {data.map((v, i) => {
      const max = Math.max(...data, 1);
      const h = Math.max(2, (v / max) * 24);
      return <span key={i} className={i === highlight || (i === data.length - 1 && v > 0) ? 'is-month' : ''} style={{ height: h }}/>;
    })}
  </div>
);

const PatternsList = ({ onOpen }) => (
  <>
    <div className="page-head">
      <div className="page-eye"><span className="glyph">✶</span> Patterns</div>
      <h1 className="page-title">Things that have <em>recurred</em>.</h1>
      <p className="page-sub">Sorted by when you last saw them. Each one is named in your words. The four "typical" quadrants below are what tends to show up — they grow gentler and more accurate as you log more occurrences.</p>
    </div>
    <ReadOnlyBanner/>
    <div className="pat-list">
      {PATTERNS.sort((a,b) => b.last_date.localeCompare(a.last_date)).map(p => (
        <div key={p.id} className="pat-card" onClick={() => onOpen(p.id)}>
          <div>
            <h3 className="pat-card-name">{p.name}</h3>
            <p className="pat-card-desc">{p.description}</p>
          </div>
          <div className="pat-card-stats">
            <span className="big">×{p.occurrences}</span>
            last seen {p.last_seen}
            <Sparkline data={p.sparkline}/>
          </div>
        </div>
      ))}
    </div>
  </>
);

const PatternDetail = ({ id, onBack, onEntry }) => {
  const p = PATTERNS.find(x => x.id === id);
  if (!p) return <div>Not found</div>;
  const occurrences = ENTRIES.flatMap(e => e.occurrences.filter(o => o.pattern === p.name).map(o => ({ ...o, entry: e })));

  return (
    <>
      <button className="back-link" onClick={onBack}>← All patterns</button>
      <div className="pat-detail-head">
        <div className="page-eye"><span className="glyph">✶</span> Pattern</div>
        <h1 className="pat-detail-name">{p.name}</h1>
        <p className="pat-detail-desc">{p.description}</p>
        <div className="pat-detail-stats">
          <div>Occurrences<strong>×{p.occurrences}</strong></div>
          <div>Last seen<strong>{p.last_seen}</strong></div>
          <div>Avg intensity<strong>{p.intensity_avg.toFixed(1)} / 5</strong></div>
        </div>
      </div>

      <div className="entry-section-eye">The typical shape</div>
      <div className="typical">
        <div className="typical-q"><span className="q-eye">Quadrant 01</span><div className="q-name">Thoughts</div><p className="q-text">{p.typical.thoughts}</p></div>
        <div className="typical-q"><span className="q-eye">Quadrant 02</span><div className="q-name">Emotions</div><p className="q-text">{p.typical.emotions}</p></div>
        <div className="typical-q"><span className="q-eye">Quadrant 03</span><div className="q-name">Behaviours</div><p className="q-text">{p.typical.behaviors}</p></div>
        <div className="typical-q"><span className="q-eye">Quadrant 04</span><div className="q-name">Body</div><p className="q-text">{p.typical.sensations}</p></div>
      </div>

      <div className="entry-section-eye">When it has shown up</div>
      <div className="timeline">
        {occurrences.map((o, i) => (
          <div key={i} className={`tl-item ${i === 0 ? 'is-recent' : ''}`}>
            <div className="tl-date">
              {new Date(o.entry.date + 'T12:00').toLocaleDateString('en-US', { month: 'long', day: 'numeric' })} · intensity {o.intensity}/5 · <a onClick={(ev)=>{ev.preventDefault(); onEntry(o.entry.id);}} style={{cursor:'pointer'}}>read entry →</a>
            </div>
            <p className="tl-trigger">Trigger: {o.trigger}</p>
            <div className="tl-quads">
              <div><em>Thoughts</em>{o.thoughts}</div>
              <div style={{marginTop:6}}><em>Body</em>{o.sensations}</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

window.PatternsList = PatternsList;
window.PatternDetail = PatternDetail;
window.Sparkline = Sparkline;
