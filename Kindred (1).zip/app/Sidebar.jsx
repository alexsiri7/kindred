/* Sidebar */

const Icon = ({ name, size = 16 }) => {
  const paths = {
    home:     <><path d="M3 10l9-7 9 7v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/></>,
    book:     <><path d="M4 4v16a2 2 0 0 0 2 2h14"/><path d="M4 4h14v18"/><path d="M8 8h6M8 12h6M8 16h4"/></>,
    layers:   <><path d="M12 2L2 8l10 6 10-6-10-6z"/><path d="M2 14l10 6 10-6"/></>,
    search:   <><circle cx="11" cy="11" r="7"/><path d="M21 21l-5-5"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v.1a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></>,
    plug:     <><path d="M9 2v6"/><path d="M15 2v6"/><path d="M5 8h14v3a7 7 0 0 1-14 0z"/><path d="M12 18v4"/></>,
    arrow:    <path d="M5 12h14M13 6l6 6-6 6"/>,
    chevron:  <path d="M9 6l6 6-6 6"/>,
    download: <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></>,
    trash:    <><path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></>,
  };
  return (
    <svg className="ico" width={size} height={size} viewBox="0 0 24 24" fill="none"
         stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
      {paths[name]}
    </svg>
  );
};

const Sidebar = ({ route, onRoute }) => {
  const items = [
    { id: 'entries',  label: 'Entries',   icon: 'book',   count: ENTRIES.length },
    { id: 'patterns', label: 'Patterns',  icon: 'layers', count: PATTERNS.length },
    { id: 'search',   label: 'Search',    icon: 'search' },
  ];
  const settings = [
    { id: 'connect',  label: 'Connect to Claude', icon: 'plug' },
    { id: 'settings', label: 'Settings',          icon: 'settings' },
  ];
  const isActive = (id) => route.split(':')[0] === id || (id === 'entries' && route.startsWith('entry'));
  return (
    <aside className="side">
      <a className="side-brand" href="#" onClick={(e)=>{e.preventDefault(); onRoute('entries');}}>
        <KindredMark size={26}/>
        <span className="wm"><em>Kindred</em><span className="dot">.</span></span>
      </a>
      <div className="side-search" onClick={() => onRoute('search')}>
        <Icon name="search" size={14}/>
        <input placeholder="Search by feeling, theme…" readOnly/>
        <span className="kbd">⌘K</span>
      </div>
      <div className="side-eye">Library</div>
      <nav className="side-nav">
        {items.map(i => (
          <button key={i.id} className={`side-link ${isActive(i.id) ? 'is-active' : ''}`} onClick={() => onRoute(i.id)}>
            <Icon name={i.icon}/>
            <span>{i.label}</span>
            {i.count != null && <span className="count">{i.count}</span>}
          </button>
        ))}
      </nav>
      <div className="side-eye">Account</div>
      <nav className="side-nav">
        {settings.map(i => (
          <button key={i.id} className={`side-link ${isActive(i.id) ? 'is-active' : ''}`} onClick={() => onRoute(i.id)}>
            <Icon name={i.icon}/>
            <span>{i.label}</span>
          </button>
        ))}
      </nav>
      <div className="side-foot">
        <div className="side-avatar">A</div>
        <div className="who">
          Alex S.
          <small>alex@kindred.local</small>
        </div>
      </div>
    </aside>
  );
};

window.Icon = Icon;
window.Sidebar = Sidebar;
