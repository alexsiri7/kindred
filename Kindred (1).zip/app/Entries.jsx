/* Entries list page — with calendar filter */

const ReadOnlyBanner = () => (
  <div className="readonly-banner">
    <span className="lock">🔒</span>
    <span><strong>Read-only.</strong> Entries are written through the journaling conversation in Claude — not from here.</span>
  </div>
);

/* Today, fixed for the prototype */
const TODAY = { y: 2026, m: 4, d: 9 }; // May 9, 2026 — month is 0-indexed

const fmtISO = (y, m, d) =>
  `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];

const EntryCalendar = ({ entries, selected, onSelect }) => {
  // Default the calendar's viewed month to May 2026 so today is in view.
  const [view, setView] = React.useState({ y: TODAY.y, m: TODAY.m });

  const entryDates = React.useMemo(() => new Set(entries.map(e => e.date)), [entries]);

  const firstDow = new Date(view.y, view.m, 1).getDay();
  const daysInMonth = new Date(view.y, view.m + 1, 0).getDate();
  const monthEntries = entries.filter(e => e.date.startsWith(`${view.y}-${String(view.m + 1).padStart(2, '0')}`)).length;

  const cells = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  const step = (delta) => {
    setView(v => {
      const nm = v.m + delta;
      if (nm < 0)  return { y: v.y - 1, m: 11 };
      if (nm > 11) return { y: v.y + 1, m: 0 };
      return { y: v.y, m: nm };
    });
  };

  const goToday = () => {
    setView({ y: TODAY.y, m: TODAY.m });
    onSelect(fmtISO(TODAY.y, TODAY.m, TODAY.d));
  };

  return (
    <aside className="cal" aria-label="Calendar">
      <div className="cal-eye"><span className="glyph">◐</span> Browse by day</div>

      <div className="cal-head">
        <button className="cal-arrow" onClick={() => step(-1)} aria-label="Previous month">‹</button>
        <div className="cal-title">
          <span className="cal-month">{MONTH_NAMES[view.m]}</span>
          <span className="cal-year">{view.y}</span>
        </div>
        <button className="cal-arrow" onClick={() => step(1)} aria-label="Next month">›</button>
      </div>

      <div className="cal-grid">
        {['S','M','T','W','T','F','S'].map((d, i) => (
          <div key={i} className="cal-dow">{d}</div>
        ))}
        {cells.map((d, i) => {
          if (d === null) return <div key={i} className="cal-cell is-empty" aria-hidden="true"/>;
          const dateStr  = fmtISO(view.y, view.m, d);
          const hasEntry = entryDates.has(dateStr);
          const isToday  = view.y === TODAY.y && view.m === TODAY.m && d === TODAY.d;
          const isSel    = selected === dateStr;
          const cls = [
            'cal-cell',
            hasEntry  && 'has-entry',
            isToday   && 'is-today',
            isSel     && 'is-selected',
          ].filter(Boolean).join(' ');
          return (
            <button
              key={i}
              className={cls}
              onClick={() => onSelect(isSel ? null : dateStr)}
              aria-label={`${MONTH_NAMES[view.m]} ${d}${hasEntry ? ', has entry' : ''}${isToday ? ', today' : ''}`}
              aria-pressed={isSel}
            >
              <span className="cal-num">{d}</span>
              {hasEntry && <span className="cal-mark" aria-hidden="true"/>}
            </button>
          );
        })}
      </div>

      <div className="cal-foot">
        <div className="cal-legend">
          <span className="lg lg-entry"><span className="sw"/> entry</span>
          <span className="lg lg-today"><span className="sw"/> today</span>
        </div>
        <div className="cal-foot-meta">
          <span>{monthEntries} this month</span>
          <button className="cal-link" onClick={goToday}>Today</button>
          {selected && <button className="cal-link" onClick={() => onSelect(null)}>Clear</button>}
        </div>
      </div>
    </aside>
  );
};

const EntriesList = ({ onOpen }) => {
  const [selected, setSelected] = React.useState(fmtISO(TODAY.y, TODAY.m, TODAY.d));

  const filtered = selected ? ENTRIES.filter(e => e.date === selected) : ENTRIES;

  // group by month
  const byMonth = {};
  filtered.forEach(e => {
    const key = `${e.month} 2026`;
    if (!byMonth[key]) byMonth[key] = [];
    byMonth[key].push(e);
  });

  const selectedLabel = selected ? (() => {
    const [y, m, d] = selected.split('-').map(Number);
    const wd = new Date(y, m - 1, d).toLocaleString('en-US', { weekday: 'long' });
    return `${wd}, ${MONTH_NAMES[m - 1]} ${d}`;
  })() : null;

  const isTodaySelected = selected === fmtISO(TODAY.y, TODAY.m, TODAY.d);

  return (
    <>
      <div className="page-head">
        <div className="page-eye"><span className="glyph">✶</span> Your library</div>
        <h1 className="page-title">A record of <em>being with</em> yourself.</h1>
        <p className="page-sub">{ENTRIES.length} entries since you started in March. Sorted by most recent. Click any entry to read the full thing.</p>
      </div>
      <ReadOnlyBanner/>

      <div className="entries-layout">
        <div className="entries-col">
          {selected && (
            <div className="filter-bar">
              <div className="filter-bar-label">
                <span className="filter-bar-eye">Showing</span>
                <em>{selectedLabel}</em>
                {isTodaySelected && <span className="filter-bar-pill">today</span>}
              </div>
              <button className="filter-bar-clear" onClick={() => setSelected(null)}>Show all entries ›</button>
            </div>
          )}

          {filtered.length === 0 && (
            <div className="empty-day">
              <div className="empty-day-mark">— no entry —</div>
              <p>
                Nothing was written on <em>{selectedLabel}</em>.
                {isTodaySelected && ' Open Kindred in Claude to start one.'}
              </p>
            </div>
          )}

          {Object.entries(byMonth).map(([month, items]) => (
            <div key={month}>
              <div className="month-div">{month}</div>
              {items.map(e => (
                <div key={e.id} className="entry-row" onClick={() => onOpen(e.id)}>
                  <div className="entry-date">
                    <span className="day">{e.day}</span>
                    {e.weekday}
                  </div>
                  <div className="entry-body">
                    <h3>{e.title}</h3>
                    <p>{e.summary.length > 200 ? e.summary.slice(0, 200) + '…' : e.summary}</p>
                    {e.occurrences.length > 0 && (
                      <div className="entry-tags">
                        {e.occurrences.map((o, i) => (
                          <span key={i} className="tag-pill">{o.pattern}</span>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="entry-meta">
                    <span className="mood">◉ {e.mood}</span>
                    {e.wordCount} words
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>

        <EntryCalendar entries={ENTRIES} selected={selected} onSelect={setSelected}/>
      </div>
    </>
  );
};

window.EntriesList = EntriesList;
window.ReadOnlyBanner = ReadOnlyBanner;
