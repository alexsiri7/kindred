/* Sample data — what the user sees in the read-only web app */

const ENTRIES = [
  {
    id: 'e1', date: '2026-04-30', day: 30, month: 'Apr', weekday: 'Thu',
    title: 'The Sunday-dread one, again',
    summary: 'It was the same one — that bracing-for-an-unnamed-thing feeling, even though it was Thursday. We named it again as Sunday dread. The body part was clear: shallow breath, jaw doing a thing. The thought underneath was the quieter one: people will be polite about it but they\'ll notice. We didn\'t try to fix it.',
    mood: 'tender', wordCount: 412,
    occurrences: [
      { pattern: 'Sunday dread', intensity: 3,
        thoughts: 'Going to drop a ball and not realise. People will be polite about it but they\'ll notice.',
        emotions: 'A low static. Bracing.',
        behaviors: 'Refreshing email. Skipping lunch.',
        sensations: 'Shallow breath. Tight jaw.',
        trigger: 'Calendar full on Friday' },
    ],
    transcript: [
      { from: 'kindred', text: 'Hey. No agenda from my side — what\'s here for you right now?' },
      { from: 'you',     text: 'It\'s that Sunday feeling again, even though it\'s Thursday. A kind of low static. I keep refreshing my email like that\'ll fix it.' },
      { from: 'kindred', text: 'That sounds tiring — the static and the refreshing both. You said "Sunday feeling," even on a Thursday. I\'m curious what makes it feel like that one in particular.' },
      { from: 'you',     text: 'I think it\'s the part where I\'m bracing for something I can\'t name.' },
    ],
  },
  {
    id: 'e2', date: '2026-04-28', day: 28, month: 'Apr', weekday: 'Tue',
    title: 'A small win, for once',
    summary: 'I got the email out. The one I\'ve been not-writing for two weeks. We talked about what that "not-writing" actually looked like — opening the draft, closing it, telling myself "later". I noticed I felt lighter even before sending; the relief was in the deciding.',
    mood: 'lighter', wordCount: 287,
    occurrences: [],
  },
  {
    id: 'e3', date: '2026-04-23', day: 23, month: 'Apr', weekday: 'Thu',
    title: 'A good walk',
    summary: 'Short one. Went for a walk before I had a reason to. Came back and the to-do list looked smaller, even though it was the same list. I think the trick is to go before I have a reason.',
    mood: 'light', wordCount: 156,
    occurrences: [],
  },
  {
    id: 'e4', date: '2026-04-18', day: 18, month: 'Apr', weekday: 'Sat',
    title: 'The 3pm wall, one more time',
    summary: 'Hit the 3pm wall hard. We named it as "3pm wall" again — seventh time this month. I noticed I keep trying to push through it instead of acknowledging it. Body: heavy, behind the eyes. We agreed I\'d try the walk thing earlier next week.',
    mood: 'tired', wordCount: 198,
    occurrences: [
      { pattern: '3pm wall', intensity: 4,
        thoughts: 'Just push through. You\'re behind. Coffee.',
        emotions: 'Foggy. A little defeated.',
        behaviors: 'Tab-switching. Snacking. More coffee.',
        sensations: 'Heavy behind the eyes. Slumped.',
        trigger: 'Big lunch' },
    ],
  },
  {
    id: 'e5', date: '2026-04-14', day: 14, month: 'Apr', weekday: 'Tue',
    title: 'Something about my dad',
    summary: 'Came in unexpectedly while I was making dinner. We sat with it for a while. Didn\'t name it as a pattern yet — felt too fresh. Just wanted it to be heard.',
    mood: 'soft', wordCount: 524,
    occurrences: [],
  },
  {
    id: 'e6', date: '2026-04-10', day: 10, month: 'Apr', weekday: 'Fri',
    title: 'The letting-people-down spiral',
    summary: 'A familiar one. Cancelled on a friend, then spent an hour writing increasingly elaborate apology messages I didn\'t send. We named the gap between what actually happened (one cancelled coffee) and the story I was telling myself (I am an unreliable person who hurts people).',
    mood: 'guilty', wordCount: 367,
    occurrences: [
      { pattern: 'The letting-people-down spiral', intensity: 4,
        thoughts: 'I am an unreliable person. They\'re going to stop inviting me.',
        emotions: 'Sharp guilt. A bit ashamed.',
        behaviors: 'Drafting and not sending. Avoiding the phone.',
        sensations: 'Tight chest. Restless.',
        trigger: 'Cancelled coffee with M.' },
    ],
  },
  {
    id: 'e7', date: '2026-04-06', day: 6, month: 'Apr', weekday: 'Mon',
    title: 'A first day kind of feeling',
    summary: 'Started the week well, surprisingly. Noticed it without trying to figure out why. We agreed not to inspect it.',
    mood: 'open', wordCount: 142,
    occurrences: [],
  },
  {
    id: 'e8', date: '2026-03-29', day: 29, month: 'Mar', weekday: 'Sun',
    title: 'Pre-trip jangle',
    summary: 'The night-before-flying feeling. Named it "pre-trip jangle". Body very on. Mind making lists about things already on lists.',
    mood: 'wired', wordCount: 213,
    occurrences: [
      { pattern: 'Pre-trip jangle', intensity: 3,
        thoughts: 'I\'ve forgotten something. Check the passport again.',
        emotions: 'Jangly. Unsettled but not unhappy.',
        behaviors: 'Re-packing. Checking timetables.',
        sensations: 'Buzzy. Hard to sit still.', trigger: 'Flight tomorrow' },
    ],
  },
];

const PATTERNS = [
  {
    id: 'p1', name: 'Sunday dread',
    description: 'The bracing-for-an-unnamed-thing feeling. Usually arrives Sundays around 4pm, but has shown up other days too.',
    occurrences: 4, last_seen: '2 days ago', last_date: '2026-04-30',
    intensity_avg: 3.0,
    typical: {
      thoughts: 'There\'s something I\'ve forgotten and I won\'t know until it\'s too late. People will be polite about it but they\'ll notice.',
      emotions: 'A low static. Quiet bracing. Sometimes a flicker of irritation underneath.',
      behaviors: 'Refreshing email. Re-reading messages. Skipping meals or eating distractedly.',
      sensations: 'Shallow breath. Jaw tight. A held quality across the shoulders.',
    },
    sparkline: [0,1,0,2,0,1,3,2,0,1,1,2],
  },
  {
    id: 'p2', name: 'The letting-people-down spiral',
    description: 'After cancelling or disappointing someone, the story balloons way past the actual thing.',
    occurrences: 2, last_seen: '3 weeks ago', last_date: '2026-04-10',
    intensity_avg: 3.5,
    typical: {
      thoughts: 'I am an unreliable person. They\'re going to stop inviting me.',
      emotions: 'Sharp guilt. A flicker of shame.',
      behaviors: 'Drafting messages I don\'t send. Avoiding the phone.',
      sensations: 'Tight chest. Restless hands.',
    },
    sparkline: [1,0,0,0,1,0,0,1,0,0,1,0],
  },
  {
    id: 'p3', name: '3pm wall',
    description: 'Afternoon energy collapse. Tends to show up after a heavy lunch or back-to-back meetings.',
    occurrences: 7, last_seen: '12 days ago', last_date: '2026-04-18',
    intensity_avg: 3.7,
    typical: {
      thoughts: 'Just push through. You\'re already behind.',
      emotions: 'Foggy. A little defeated.',
      behaviors: 'Tab-switching. Snacking. More coffee.',
      sensations: 'Heavy behind the eyes. Slumped posture.',
    },
    sparkline: [0,1,2,1,0,2,3,4,2,1,2,4],
  },
  {
    id: 'p4', name: 'Pre-trip jangle',
    description: 'The night-before-travel restlessness. Mind making lists about things already on lists.',
    occurrences: 3, last_seen: '5 weeks ago', last_date: '2026-03-29',
    intensity_avg: 2.7,
    typical: {
      thoughts: 'I\'ve forgotten something. Check the passport again.',
      emotions: 'Jangly. Unsettled but not unhappy.',
      behaviors: 'Re-packing. Checking timetables.',
      sensations: 'Buzzy. Hard to sit still.',
    },
    sparkline: [0,0,0,0,0,1,0,0,0,2,0,0],
  },
  {
    id: 'p5', name: 'The one about my dad',
    description: 'Comes in unexpectedly. Hasn\'t settled into a typical shape yet. We\'ve mostly just been with it.',
    occurrences: 1, last_seen: '16 days ago', last_date: '2026-04-14',
    intensity_avg: 4.0,
    typical: {
      thoughts: '—', emotions: 'Soft. A little exposed.', behaviors: '—', sensations: 'A held breath, then a long exhale.',
    },
    sparkline: [0,0,0,0,0,0,0,0,1,0,0,0],
  },
];

window.ENTRIES = ENTRIES;
window.PATTERNS = PATTERNS;
