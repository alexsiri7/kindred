/* Entry detail page */

const EntryDetail = ({ id, onBack, onPattern }) => {
  const e = ENTRIES.find(x => x.id === id);
  const [showTranscript, setShowTranscript] = React.useState(false);
  if (!e) return <div>Not found</div>;

  const fullDate = new Date(e.date + 'T12:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });

  return (
    <>
      <button className="back-link" onClick={onBack}>← All entries</button>
      <div className="page-eye"><span className="glyph">✶</span> Entry</div>
      <div className="entry-detail-head">
        <div className="entry-detail-date">{fullDate}</div>
        <div className="entry-detail-meta">
          <span className="mood-big">◉ {e.mood}</span>
          <span style={{whiteSpace:'nowrap'}}>{e.wordCount} words · {e.transcript ? 'transcript on' : 'summary only'}</span>
        </div>
      </div>

      <p className="entry-summary">{e.summary}</p>

      {e.occurrences.length > 0 && (
        <>
          <div className="entry-section-eye">Patterns named in this entry</div>
          {e.occurrences.map((o, i) => (
            <div key={i} className="occ-card">
              <div className="occ-head">
                <a className="occ-name" onClick={(ev)=>{ev.preventDefault(); onPattern(PATTERNS.find(p => p.name === o.pattern)?.id);}}
                   style={{cursor:'pointer'}}>
                  <span className="glyph">✶</span>{o.pattern}
                </a>
                <span className="occ-intensity">intensity {o.intensity}/5 · trigger: {o.trigger}</span>
              </div>
              <div className="occ-quads">
                <div className="occ-quad"><span className="occ-quad-label">Thoughts</span>{o.thoughts}</div>
                <div className="occ-quad"><span className="occ-quad-label">Emotions</span>{o.emotions}</div>
                <div className="occ-quad"><span className="occ-quad-label">Behaviours</span>{o.behaviors}</div>
                <div className="occ-quad"><span className="occ-quad-label">Body</span>{o.sensations}</div>
              </div>
            </div>
          ))}
        </>
      )}

      {e.transcript && (
        <div className="transcript-wrap">
          <button className={`transcript-toggle ${showTranscript ? 'is-open' : ''}`} onClick={() => setShowTranscript(s => !s)}>
            <span className="chev">▸</span>
            {showTranscript ? 'Hide' : 'Show'} full transcript ({e.transcript.length} messages)
          </button>
          {showTranscript && (
            <div className="transcript-body">
              {e.transcript.map((m, i) => (
                <div key={i} className={`t-msg ${m.from}`}>
                  <span className="who">{m.from}</span>
                  <span className="text">{m.text}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </>
  );
};

window.EntryDetail = EntryDetail;
