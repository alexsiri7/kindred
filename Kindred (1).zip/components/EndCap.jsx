const EndCap = () => (
  <section className="endcap" id="start">
    <div className="endcap-inner">
      <div className="eyebrow" style={{color:'rgba(250,247,242,0.5)'}}>
        <span className="glyph" style={{color:'var(--terracotta-3)'}}>✶</span> Ready when you are
      </div>
      <h2>Talk to Claude. Let <em>Kindred</em> hold the rest.</h2>
      <p>
        Add the connector to Claude.ai, sign in with Google, type <code style={{background:'rgba(250,247,242,0.08)',color:'var(--paper)',padding:'2px 6px',borderRadius:4,fontFamily:'var(--font-mono)',fontSize:14}}>/kindred-start</code>.
        That's the whole onboarding.
      </p>
      <div style={{display:'flex', gap:'12px', justifyContent:'center', flexWrap:'wrap'}}>
        <button className="btn btn-primary btn-lg" onClick={() => alert('Demo only — connect flow lives in the real app')}>Connect to Claude.ai</button>
        <button className="btn btn-ghost btn-lg" style={{color:'var(--paper)', border:'1px solid rgba(250,247,242,0.25)'}}>
          Read the PRD →
        </button>
      </div>
    </div>
  </section>
);

const Foot = () => (
  <footer className="foot">
    <div>
      <span style={{color:'var(--terracotta-3)'}}>✶</span> Kindred — a small thing made by InterstellarAI
    </div>
    <div>
      <a href="#privacy">Privacy</a>
      <a href="#">Terms</a>
      <a href="#">Field notes</a>
      <a href="https://github.com/alexsiri7/kindred">GitHub ↗</a>
    </div>
    <div>Made in orbit · v0.1</div>
  </footer>
);

window.EndCap = EndCap;
window.Foot = Foot;
