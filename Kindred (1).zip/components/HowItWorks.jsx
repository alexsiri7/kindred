const HowItWorks = () => (
  <section className="how" id="how">
    <div className="wrap">
      <div className="section-head center">
        <div className="eyebrow"><span className="glyph">✶</span> How it works</div>
        <h2 className="section-title">Three small <em>commands</em>. One quiet practice.</h2>
        <p className="section-sub">
          Kindred lives inside Claude as a connector. Add it once, and three slash commands appear —
          one to begin, one to look at a pattern, one to close.
        </p>
      </div>

      <div className="steps">
        <div className="step">
          <div className="step-num">
            <span>Step 01</span><span className="glyph">✶</span>
          </div>
          <h3><em>Begin</em> with a gentle question</h3>
          <p>Claude greets you with one open prompt — “How are you arriving today?” — and stays in listening mode. No advice, no reframing, no silver linings.</p>
          <span className="step-cmd">/kindred-start</span>
        </div>
        <div className="step">
          <div className="step-num">
            <span>Step 02</span><span className="glyph">✶</span>
          </div>
          <h3>Examine a <em>pattern</em>, only if you want to</h3>
          <p>When something feels worth pinning down, walk it through the four quadrants. Name the pattern in your own words. Kindred remembers it for next time.</p>
          <span className="step-cmd">/kindred-hcb</span>
        </div>
        <div className="step">
          <div className="step-num">
            <span>Step 03</span><span className="glyph">✶</span>
          </div>
          <h3><em>Close</em> the session, gently</h3>
          <p>Claude offers a one-paragraph summary in your language. You approve it. The entry saves. No homework, no streak, no “see you tomorrow!”.</p>
          <span className="step-cmd">/kindred-close</span>
        </div>
      </div>
    </div>
  </section>
);
window.HowItWorks = HowItWorks;
