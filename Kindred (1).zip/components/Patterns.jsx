const Patterns = () => (
  <section className="patterns" id="patterns">
    <div className="wrap pat-grid">
      <div className="pat-text">
        <div className="eyebrow"><span className="glyph">✶</span> The Hot Cross Bun</div>
        <h2 className="section-title">A small framework, <em>only</em> when you reach for it.</h2>
        <p className="section-sub">
          Borrowed from CBT, used gently. Four quadrants — thoughts, emotions, behaviours, body —
          to help name what's actually here. You name the pattern. Kindred keeps a list.
        </p>

        <div className="pat-named">
          <div className="pat-named-h">A few you might name</div>
          <div className="pat-chips">
            <span className="pat-chip"><span className="dot"></span>Sunday dread <span className="count">×4</span></span>
            <span className="pat-chip"><span className="dot"></span>The letting-people-down spiral <span className="count">×2</span></span>
            <span className="pat-chip"><span className="dot"></span>3pm wall <span className="count">×7</span></span>
            <span className="pat-chip"><span className="dot"></span>The one about my dad <span className="count">×1</span></span>
            <span className="pat-chip"><span className="dot"></span>Pre-trip jangle <span className="count">×3</span></span>
          </div>
        </div>
      </div>

      <div className="bun" aria-label="Hot Cross Bun framework">
        <div className="bun-q">
          <span className="q-eye">Quadrant 01</span>
          <span className="q-name">Thoughts</span>
          <span className="q-ex">“What was I telling myself?”</span>
        </div>
        <div className="bun-q">
          <span className="q-eye">Quadrant 02</span>
          <span className="q-name">Emotions</span>
          <span className="q-ex">“How did I feel — your word, not a label.”</span>
        </div>
        <div className="bun-q">
          <span className="q-eye">Quadrant 03</span>
          <span className="q-name">Behaviours</span>
          <span className="q-ex">“What did I do, or not do?”</span>
        </div>
        <div className="bun-q">
          <span className="q-eye">Quadrant 04</span>
          <span className="q-name">Body</span>
          <span className="q-ex">“What was happening physically — breath, jaw, shoulders.”</span>
        </div>
        <div className="bun-center">HCB</div>
      </div>
    </div>
  </section>
);
window.Patterns = Patterns;
