/* Conversation — the centerpiece.
   An interactive demo of a reflective journaling session in Claude
   with the Kindred MCP active. Plays automatically; can be replayed. */

const SCRIPT = [
  { kind: 'slash',   from: 'You',     text: '/kindred-start', delay: 600 },
  { kind: 'kindred', from: 'Kindred', delay: 900,
    text: <p><em>Hey. No agenda from my side — what's here for you right now?</em></p> },
  { kind: 'user',    from: 'You',     delay: 1100,
    text: <p>It's that Sunday feeling again, even though it's Thursday. A kind of low static. I keep refreshing my email like that'll fix it.</p> },
  { kind: 'kindred', from: 'Kindred', delay: 1300,
    text: <>
      <p>That sounds tiring — the static and the refreshing both.</p>
      <p>You said <em>“Sunday feeling”</em>, even on a Thursday. I'm curious what makes it feel like that one in particular, if you want to sit with it for a moment.</p>
    </> },
  { kind: 'user',    from: 'You',     delay: 1200,
    text: <p>I think it's the part where I'm bracing for something I can't name. Like there's a thing on my list I've forgotten and I won't know until it's too late.</p> },
  { kind: 'kindred', from: 'Kindred', delay: 1300,
    text: <p>Bracing for an unnamed thing. That's a lot to carry quietly. Do you want to keep talking about it as it is, or look at it more structurally — we could try /kindred-hcb if it'd help.</p> },
  { kind: 'slash',   from: 'You',     text: '/kindred-hcb', delay: 800 },
  { kind: 'tool',    delay: 700,
    name: 'list_patterns',
    args: '()',
    result: '→ ["sunday dread", "the letting-people-down spiral"]' },
  { kind: 'kindred', from: 'Kindred', delay: 1100,
    text: <p>Okay. Take it slow. <em>What were you telling yourself</em>, just before the static showed up?</p> },
  { kind: 'user',    from: 'You',     delay: 1100,
    text: <p>Something like — “you're going to drop a ball and not realise.” Plus a quieter one underneath: “people will be polite about it but they'll notice.”</p> },
  { kind: 'kindred', from: 'Kindred', delay: 1300,
    text: <p>Thank you for naming both. The quieter one feels like it has more weight. And in your body — anything noticeable? Shoulders, breath, anywhere?</p> },
  { kind: 'user',    from: 'You',     delay: 1000,
    text: <p>Shallow breath. And my jaw is doing a thing.</p> },
  { kind: 'kindred', from: 'Kindred', delay: 1300,
    text: <p>Does this feel like the <em>“Sunday dread”</em> one you've named before, or something new?</p> },
  { kind: 'user',    from: 'You',     delay: 900,
    text: <p>Same one. Definitely.</p> },
  { kind: 'tool',    delay: 700,
    name: 'log_occurrence',
    args: '(pattern_name: "sunday dread", thoughts, emotions, …)',
    result: '✓ saved · 4th occurrence' },
  { kind: 'kindred', from: 'Kindred', delay: 1100,
    text: <p>Logged. Want to keep talking, or close out for now?</p> },
];

const Conversation = () => {
  const [step, setStep] = React.useState(0);
  const [playing, setPlaying] = React.useState(true);
  const [typing, setTyping] = React.useState(false);
  const bodyRef = React.useRef(null);
  const timerRef = React.useRef(null);

  // advance the script
  React.useEffect(() => {
    if (!playing) return;
    if (step >= SCRIPT.length) return;

    const item = SCRIPT[step];
    const showTyping = item.kind === 'kindred';
    if (showTyping) {
      setTyping(true);
      timerRef.current = setTimeout(() => {
        setTyping(false);
        setStep(s => s + 1);
      }, item.delay);
    } else {
      timerRef.current = setTimeout(() => {
        setStep(s => s + 1);
      }, item.delay);
    }
    return () => clearTimeout(timerRef.current);
  }, [step, playing]);

  // auto-scroll
  React.useEffect(() => {
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [step, typing]);

  const replay = () => {
    clearTimeout(timerRef.current);
    setStep(0);
    setTyping(false);
    setPlaying(true);
  };
  const togglePlay = () => {
    if (step >= SCRIPT.length) { replay(); return; }
    setPlaying(p => !p);
  };

  const visible = SCRIPT.slice(0, step);
  const done = step >= SCRIPT.length;

  return (
    <section className="conversation" id="demo">
      <div className="conv-grid">
        <div className="conv-text">
          <div className="eyebrow"><span className="glyph">✶</span> A real session, more or less</div>
          <h2 className="section-title">It's Claude. With <em>somewhere</em> for it to land.</h2>
          <p className="section-sub">
            You journal by talking to Claude. Kindred adds the parts a journal needs:
            a place to keep entries, a way to name recurring patterns, and tools that only
            run when you ask them to.
          </p>
          <ul className="conv-list">
            <li><span className="mark">01</span><span><strong>Validation before analysis.</strong> The default stance is being-with, not problem-solving.</span></li>
            <li><span className="mark">02</span><span><strong>You own the vocabulary.</strong> Patterns are named in your words. The AI suggests; never imposes.</span></li>
            <li><span className="mark">03</span><span><strong>No surveillance.</strong> Past entries stay quiet unless you ask.</span></li>
            <li><span className="mark">04</span><span><strong>One write path.</strong> The web app reads. The conversation is where things are written.</span></li>
          </ul>
          <div className="conv-ctrls">
            <button className={`conv-ctrl-btn ${playing && !done ? 'is-on' : ''}`} onClick={togglePlay}>
              {done ? '↻ Replay' : (playing ? '❚❚ Pause' : '▶ Play')}
            </button>
            <button className="conv-ctrl-btn" onClick={replay}>↻ Restart</button>
            <span style={{fontFamily:'var(--font-mono)', fontSize:11, color:'var(--ink-3)', letterSpacing:'0.06em'}}>
              {Math.min(step, SCRIPT.length)} / {SCRIPT.length}
            </span>
          </div>
        </div>

        <div className="chat" role="region" aria-label="Demo conversation">
          <div className="chat-chrome">
            <div className="chrome-dots"><span></span><span></span><span></span></div>
            <div className="chrome-title">
              <span className="lock">🔒</span>
              claude.ai · journal — Thursday, 1:48 PM
            </div>
            <div className="chrome-mcp"><span className="pulse"></span> kindred · mcp</div>
          </div>

          <div className="chat-body" ref={bodyRef}>
            {visible.map((m, i) => {
              if (m.kind === 'tool') {
                return (
                  <div key={i} className="tool-call">
                    <div className="tc-head">
                      <span className="arrow">→</span>
                      <span>kindred mcp call</span>
                    </div>
                    <div>
                      <span className="tc-name">{m.name}</span><span className="tc-args">{m.args}</span>
                    </div>
                    <div className="tc-result">{m.result}</div>
                  </div>
                );
              }
              if (m.kind === 'slash') {
                return (
                  <div key={i} className="msg slash user">
                    <div className="msg-avatar" aria-hidden="true">A</div>
                    <div className="msg-body">
                      <span className="msg-from">{m.from}</span>
                      <div className="msg-text">
                        <span className="cmd-glyph">/</span>{m.text.slice(1)}
                      </div>
                    </div>
                  </div>
                );
              }
              return (
                <div key={i} className={`msg ${m.kind}`}>
                  <div className="msg-avatar" aria-hidden="true">{m.kind === 'kindred' ? 'K' : 'A'}</div>
                  <div className="msg-body">
                    <span className="msg-from">{m.from}</span>
                    <div className="msg-text">{m.text}</div>
                  </div>
                </div>
              );
            })}
            {typing && (
              <div className="msg kindred">
                <div className="msg-avatar" aria-hidden="true">K</div>
                <div className="msg-body">
                  <span className="msg-from">Kindred</span>
                  <div className="typing"><span></span><span></span><span></span></div>
                </div>
              </div>
            )}
          </div>

          <form className="chat-input" onSubmit={(e) => e.preventDefault()}>
            <span className="slash-hint">/  type a slash command</span>
            <input type="text" placeholder={done ? "Try /kindred-close to wrap up…" : "Or just keep talking."} />
            <button type="submit" className="send-btn" aria-label="Send">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.25" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};
window.Conversation = Conversation;
