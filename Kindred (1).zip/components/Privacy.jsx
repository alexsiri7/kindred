const Privacy = () => (
  <section className="privacy" id="privacy">
    <div className="wrap">
      <div className="section-head">
        <div className="eyebrow"><span className="glyph">✶</span> Boring privacy claims, kept honest</div>
        <h2 className="section-title">Your <em>journal</em>. Not our dataset.</h2>
      </div>
      <div className="privacy-grid">
        <div className="priv">
          <div className="priv-eye">01 / Encrypted at rest</div>
          <h4>Stored on Supabase, scoped to you.</h4>
          <p>Row-level security on every table — cross-user reads are physically impossible from app code, even if a query forgets a where-clause.</p>
        </div>
        <div className="priv">
          <div className="priv-eye">02 / No training</div>
          <h4>Your words don't train anything.</h4>
          <p>We don't train models, and we pick providers with no-training policies. We <em>don't</em> claim end-to-end — the LLM has to read what you write.</p>
        </div>
        <div className="priv">
          <div className="priv-eye">03 / No surveillance</div>
          <h4>The AI won't volunteer your past.</h4>
          <p>“You've felt this way 5 Sundays in a row” — never. Past entries surface only when you ask for them, in the conversation or the web app.</p>
        </div>
        <div className="priv">
          <div className="priv-eye">04 / One way out</div>
          <h4>Export everything. Delete it all.</h4>
          <p>Two buttons in settings. Export gives a JSON dump of every entry, pattern, and occurrence. Delete is a hard cascade. No “are you sure” theatre.</p>
        </div>
      </div>
    </div>
  </section>
);
window.Privacy = Privacy;
