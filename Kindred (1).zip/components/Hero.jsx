const Hero = () => (
  <section className="hero" id="home">
    <div className="hero-grid">
      <div className="hero-text">
        <div className="eyebrow">
          <span className="glyph">✶</span> Reflective journaling, via Claude
        </div>
        <h1 className="hero-head">
          <span className="ink">A journal that</span><br/>
          <em>listens</em> <span className="ink">first.</span>
        </h1>
        <p className="hero-lede">
          Kindred is reflective journaling through Claude — you talk, it stays with you.
          Claude is the conversation; Kindred is the memory and the structure.
          No mood scores, no streaks, no nudges. Just a quiet companion that remembers.
        </p>
        <div className="hero-ctas">
          <button className="btn btn-primary btn-lg" onClick={() => document.getElementById('demo')?.scrollIntoView({behavior:'smooth', block:'start'})}>
            See a session
          </button>
          <button className="btn btn-link btn-md" onClick={() => document.getElementById('how')?.scrollIntoView({behavior:'smooth', block:'start'})}>
            How it works  →
          </button>
        </div>
        <div className="hero-meta">
          <span><span className="dot">◉</span> MCP server</span>
          <span>✶ Read-only web app</span>
          <span>· Your data, your vocabulary</span>
        </div>
      </div>

      <div className="hero-art" aria-hidden="true">
        <div className="hero-orbit">
          <img src="assets/illustration-orbit.svg" alt=""/>
        </div>

        <div className="entry-peek entry-peek-1">
          <div className="meta">
            <span>Apr 28 · Tue</span>
            <span className="mood">◉ tender</span>
          </div>
          <h4>The Sunday-dread one, again</h4>
          <p>I noticed it earlier today than usual — somewhere around three.
             Not catastrophic. More like a draft under a door.</p>
          <div className="tags">
            <span className="tag-pill">sunday dread</span>
            <span className="tag-pill">3rd this month</span>
          </div>
        </div>

        <div className="entry-peek entry-peek-2">
          <div className="meta">
            <span>Apr 23 · Thu</span>
            <span className="mood" style={{color:'var(--moss)'}}>◉ light</span>
          </div>
          <h4>A good walk</h4>
          <p>I think the trick is to go before I have a reason.</p>
        </div>
      </div>
    </div>
  </section>
);
window.Hero = Hero;
